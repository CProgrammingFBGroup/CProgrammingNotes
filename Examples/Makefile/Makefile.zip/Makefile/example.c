/*

     example.c

     This is a simple program that is used for
     the demonstration of the use of a Makefile.

     Written by Matthew Campbell on Tuesday March 12, 2019.

*/

#include <stdio.h>

int main( void )
{
     printf( "\
It compiled and ran.  You must have done everything correctly.\n" );
     return 0;
}

/* EOF example.c */