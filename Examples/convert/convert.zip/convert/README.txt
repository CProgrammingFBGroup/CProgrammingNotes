This is my English to metric conversion software.

Two different versions are available.  One version is for devices that support an x86 instruction set which is what my tablet uses.  The other version is for devices that support an ARM instruction set which is what my phone uses.  ARM means Advanced RISC Machine.  RISC means Reduced Instruction Set Computer.

It is possible that neither version will be compatible with your device.  Some devices are able to use one of them, but not all devices have been able to install either of them.

The compiler/IDE that I used to make this app gives it certain process privileges.  I have asked the developer about this and was told that it was not possible to assign less privileges.  The source code for this program is available in the same directory as this text file.

<EOF>
