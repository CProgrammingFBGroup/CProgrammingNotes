The mhtml file may be viewed with your Chrome browser.
The pdf file may be viewed with any compatible pdf viewer.

This web page was found at https://www.ascii-code.com/
